# Marks build_report as a package and documents public exports.

from .build_excel_report import build_excel_report

__all__ = ["build_excel_report"]
